package com.project.demo.logic.entity.rol;

public enum RoleEnum {
    USER,
    SUPER_ADMIN
}
